import os, hmac, hashlib, sqlite3, json
from datetime import datetime
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from dotenv import load_dotenv

load_dotenv()
app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "dev-only-change-me")
DB = os.path.join(os.path.dirname(__file__), "restaurant.db")
CURRENCY = os.getenv("CURRENCY", "INR")

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con

def init_db():
    con = db()
    con.executescript("""
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'admin'
    );
    CREATE TABLE IF NOT EXISTS menu (
      id INTEGER PRIMARY KEY, name TEXT NOT NULL, category TEXT NOT NULL,
      price REAL NOT NULL CHECK(price >= 0), available INTEGER NOT NULL DEFAULT 1
    );
    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY, order_type TEXT NOT NULL, table_no TEXT,
      customer_name TEXT, phone TEXT, address TEXT, status TEXT NOT NULL DEFAULT 'New',
      subtotal REAL NOT NULL, tax REAL NOT NULL, total REAL NOT NULL,
      payment_method TEXT NOT NULL, payment_status TEXT NOT NULL DEFAULT 'Pending',
      razorpay_order_id TEXT, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS order_items (
      id INTEGER PRIMARY KEY, order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
      menu_id INTEGER REFERENCES menu(id), item_name TEXT NOT NULL,
      quantity INTEGER NOT NULL, unit_price REAL NOT NULL
    );
    """)
    if not con.execute("SELECT id FROM users LIMIT 1").fetchone():
        username = os.getenv("ADMIN_USERNAME", "admin")
        password = os.getenv("ADMIN_PASSWORD", "ChangeThisPassword123!")
        con.execute("INSERT INTO users(username,password_hash) VALUES(?,?)",
                    (username, generate_password_hash(password)))
    if not con.execute("SELECT id FROM menu LIMIT 1").fetchone():
        starter = [
          ("Paneer Butter Masala","Main Course",240),("Veg Biryani","Rice",180),
          ("Butter Naan","Bread",45),("Masala Dosa","South Indian",130),
          ("Cold Coffee","Beverages",110),("Gulab Jamun","Dessert",70)
        ]
        con.executemany("INSERT INTO menu(name,category,price) VALUES(?,?,?)", starter)
    con.commit()
    con.close()

def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not session.get("user_id"):
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapped

def razorpay_client():
    key_id, secret = os.getenv("RAZORPAY_KEY_ID"), os.getenv("RAZORPAY_KEY_SECRET")
    if not key_id or not secret:
        return None
    import razorpay
    return razorpay.Client(auth=(key_id, secret))

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        con = db()
        user = con.execute("SELECT * FROM users WHERE username=?", (request.form.get("username",""),)).fetchone()
        con.close()
        if user and check_password_hash(user["password_hash"], request.form.get("password","")):
            session.clear()
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            return redirect(url_for("dashboard"))
        flash("Invalid username or password.", "error")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/")
@login_required
def dashboard():
    con = db()
    today = datetime.now().strftime("%Y-%m-%d")
    stats = con.execute("""SELECT COUNT(*) orders,
      COALESCE(SUM(CASE WHEN payment_status='Paid' THEN total ELSE 0 END),0) revenue,
      COALESCE(SUM(CASE WHEN status NOT IN ('Served','Completed','Cancelled') THEN 1 ELSE 0 END),0) active
      FROM orders WHERE substr(created_at,1,10)=?""", (today,)).fetchone()
    recent = con.execute("SELECT * FROM orders ORDER BY id DESC LIMIT 8").fetchall()
    con.close()
    return render_template("dashboard.html", stats=stats, recent=recent)

@app.route("/pos")
@login_required
def pos():
    con = db()
    menu = con.execute("SELECT * FROM menu WHERE available=1 ORDER BY category,name").fetchall()
    con.close()
    return render_template("pos.html", menu=menu)

@app.route("/api/menu")
@login_required
def api_menu():
    con = db()
    rows = con.execute("SELECT id,name,category,price FROM menu WHERE available=1 ORDER BY name").fetchall()
    con.close()
    return jsonify([dict(r) for r in rows])

@app.route("/api/orders", methods=["POST"])
@login_required
def create_order():
    data = request.get_json(silent=True) or {}
    items = data.get("items", [])
    if not items:
        return jsonify(error="Add at least one item."), 400
    order_type = data.get("order_type", "Dine-in")
    if order_type not in ("Dine-in","Takeaway","Delivery"):
        return jsonify(error="Invalid order type."), 400
    method = data.get("payment_method", "Cash")
    if method not in ("Cash","UPI","Card"):
        return jsonify(error="Invalid payment method."), 400

    con = db()
    clean, subtotal = [], 0.0
    for item in items:
        try:
            menu_id, qty = int(item["id"]), int(item["quantity"])
        except (KeyError, ValueError, TypeError):
            con.close(); return jsonify(error="Invalid item or quantity."), 400
        if qty < 1 or qty > 100:
            con.close(); return jsonify(error="Quantity must be between 1 and 100."), 400
        row = con.execute("SELECT id,name,price FROM menu WHERE id=? AND available=1", (menu_id,)).fetchone()
        if not row:
            con.close(); return jsonify(error="A selected menu item is unavailable."), 400
        line = float(row["price"]) * qty
        subtotal += line
        clean.append((row["id"], row["name"], qty, float(row["price"])))

    tax = round(subtotal * 0.05, 2)  # Demo GST setting: 5%; configure with accountant before production.
    total = round(subtotal + tax, 2)
    status = "Pending"
    rp_order_id = None

    # Razorpay checkout is used only when credentials are configured.
    # UPI/Card selections without credentials are saved as unpaid manual/demo transactions.
    client = razorpay_client() if method in ("UPI","Card") else None
    if client:
        try:
            rp = client.order.create({"amount": int(round(total*100)), "currency": CURRENCY,
                                      "receipt": "rest-" + datetime.now().strftime("%y%m%d%H%M%S")})
            rp_order_id = rp["id"]
        except Exception:
            con.close()
            return jsonify(error="Payment gateway could not create an order. Check Razorpay credentials."), 502

    cur = con.execute("""INSERT INTO orders(order_type,table_no,customer_name,phone,address,
      subtotal,tax,total,payment_method,payment_status,razorpay_order_id,created_at)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
      (order_type, data.get("table_no"), data.get("customer_name"), data.get("phone"),
       data.get("address"), subtotal, tax, total, method, status, rp_order_id,
       datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
    order_id = cur.lastrowid
    con.executemany("""INSERT INTO order_items(order_id,menu_id,item_name,quantity,unit_price)
      VALUES(?,?,?,?,?)""", [(order_id,*x) for x in clean])
    if method == "Cash":
        # Cash is marked paid only after cashier confirms receipt in the POS.
        if data.get("cash_received") is True:
            con.execute("UPDATE orders SET payment_status='Paid' WHERE id=?", (order_id,))
    con.commit()
    con.close()
    return jsonify(order_id=order_id, total=total, razorpay_order_id=rp_order_id,
                   razorpay_key=os.getenv("RAZORPAY_KEY_ID") if rp_order_id else None,
                   payment_mode="gateway" if rp_order_id else "manual")

@app.route("/api/payment/verify", methods=["POST"])
@login_required
def verify_payment():
    data = request.get_json(silent=True) or {}
    order_id = data.get("order_id")
    payment_id = data.get("razorpay_payment_id","")
    razorpay_order_id = data.get("razorpay_order_id","")
    signature = data.get("razorpay_signature","")
    secret = os.getenv("RAZORPAY_KEY_SECRET","")
    if not all([order_id,payment_id,razorpay_order_id,signature,secret]):
        return jsonify(error="Missing payment verification details."), 400
    expected = hmac.new(secret.encode(),
        f"{razorpay_order_id}|{payment_id}".encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, signature):
        return jsonify(error="Payment signature verification failed."), 400
    con = db()
    order = con.execute("SELECT razorpay_order_id FROM orders WHERE id=?", (order_id,)).fetchone()
    if not order or order["razorpay_order_id"] != razorpay_order_id:
        con.close(); return jsonify(error="Order does not match payment."), 400
    con.execute("UPDATE orders SET payment_status='Paid' WHERE id=?", (order_id,))
    con.commit(); con.close()
    return jsonify(ok=True)

@app.route("/api/orders/<int:order_id>/cash-paid", methods=["POST"])
@login_required
def cash_paid(order_id):
    con = db()
    cur = con.execute("UPDATE orders SET payment_status='Paid' WHERE id=? AND payment_method='Cash'", (order_id,))
    con.commit(); con.close()
    return jsonify(ok=cur.rowcount == 1)

@app.route("/orders")
@login_required
def orders():
    con = db()
    rows = con.execute("SELECT * FROM orders ORDER BY id DESC LIMIT 200").fetchall()
    con.close()
    return render_template("orders.html", orders=rows)

@app.route("/orders/<int:order_id>")
@login_required
def order_detail(order_id):
    con = db()
    order = con.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
    items = con.execute("SELECT * FROM order_items WHERE order_id=?", (order_id,)).fetchall()
    con.close()
    if not order: return "Order not found", 404
    return render_template("receipt.html", order=order, items=items)

@app.route("/kitchen")
@login_required
def kitchen():
    con = db()
    rows = con.execute("""SELECT * FROM orders WHERE status NOT IN ('Served','Completed','Cancelled')
      ORDER BY id ASC""").fetchall()
    con.close()
    return render_template("kitchen.html", orders=rows)

@app.route("/api/orders/<int:order_id>/status", methods=["POST"])
@login_required
def update_status(order_id):
    status = (request.get_json(silent=True) or {}).get("status")
    if status not in ("New","Preparing","Ready","Served","Completed","Cancelled"):
        return jsonify(error="Invalid status"), 400
    con = db()
    cur = con.execute("UPDATE orders SET status=? WHERE id=?", (status,order_id))
    con.commit(); con.close()
    return jsonify(ok=cur.rowcount == 1)

@app.route("/menu", methods=["GET","POST"])
@login_required
def menu_admin():
    con = db()
    if request.method == "POST":
        action = request.form.get("action")
        if action == "add":
            try:
                price = float(request.form.get("price",""))
                if price < 0: raise ValueError()
                con.execute("INSERT INTO menu(name,category,price) VALUES(?,?,?)",
                    (request.form["name"].strip(),request.form["category"].strip(),price))
                con.commit(); flash("Menu item added.", "success")
            except (ValueError, KeyError):
                flash("Enter a valid item name, category and price.", "error")
        elif action == "toggle":
            con.execute("UPDATE menu SET available=1-available WHERE id=?", (request.form.get("id"),))
            con.commit()
        con.close()
        return redirect(url_for("menu_admin"))
    rows = con.execute("SELECT * FROM menu ORDER BY category,name").fetchall()
    con.close()
    return render_template("menu.html", menu=rows)

@app.route("/reports")
@login_required
def reports():
    con = db()
    daily = con.execute("""SELECT substr(created_at,1,10) day, COUNT(*) orders,
      ROUND(SUM(CASE WHEN payment_status='Paid' THEN total ELSE 0 END),2) paid_sales
      FROM orders GROUP BY day ORDER BY day DESC LIMIT 14""").fetchall()
    methods = con.execute("""SELECT payment_method, COUNT(*) count,
      ROUND(SUM(CASE WHEN payment_status='Paid' THEN total ELSE 0 END),2) paid
      FROM orders GROUP BY payment_method""").fetchall()
    con.close()
    return render_template("reports.html", daily=daily, methods=methods)

@app.route("/health")
def health():
    return jsonify(status="ok", app="My Restaurant POS")

if __name__ == "__main__":
    init_db()
    app.run(host="127.0.0.1", port=5000, debug=True)

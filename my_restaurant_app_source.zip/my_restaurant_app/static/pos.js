let cart = {};
function addItem(id,name,price){if(!cart[id])cart[id]={id,name,price,quantity:0};cart[id].quantity++;renderCart();}
function changeQty(id,delta){cart[id].quantity+=delta;if(cart[id].quantity<=0)delete cart[id];renderCart();}
function money(n){return '₹'+Number(n).toFixed(2);}
function renderCart(){
 const box=document.getElementById('cartItems');let rows=Object.values(cart);
 box.innerHTML=rows.length?rows.map(x=>`<div class="cartrow"><div><b>${escapeHtml(x.name)}</b><small>${money(x.price)} each</small></div><div class="qty"><button onclick="changeQty(${x.id},-1)">−</button><b>${x.quantity}</b><button onclick="changeQty(${x.id},1)">+</button></div><b>${money(x.price*x.quantity)}</b></div>`).join(''):'<p class="muted">No items selected.</p>';
 let sub=rows.reduce((s,x)=>s+x.price*x.quantity,0),tax=sub*.05;
 document.getElementById('subtotal').textContent=money(sub);document.getElementById('tax').textContent=money(tax);document.getElementById('total').textContent=money(sub+tax);
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function toggleFields(){let t=document.getElementById('orderType').value;document.getElementById('tableField').classList.toggle('hidden',t!=='Dine-in');document.getElementById('customerFields').classList.toggle('hidden',t==='Dine-in');document.getElementById('addressField').classList.toggle('hidden',t!=='Delivery');}
async function submitOrder(){
 const items=Object.values(cart).map(x=>({id:x.id,quantity:x.quantity}));if(!items.length){alert('Please add menu items.');return;}
 const type=document.getElementById('orderType').value,method=document.getElementById('paymentMethod').value;
 const payload={items,order_type:type,payment_method:method,table_no:document.getElementById('tableNo').value,
 customer_name:document.getElementById('customerName').value,phone:document.getElementById('phone').value,
 address:document.getElementById('address').value,cash_received:document.getElementById('cashReceived').checked};
 const msg=document.getElementById('message');msg.textContent='Creating order…';
 const response=await fetch('/api/orders',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
 const result=await response.json();if(!response.ok){msg.textContent=result.error||'Order failed.';return;}
 if(result.razorpay_order_id && result.razorpay_key){
   if(!window.Razorpay){msg.textContent='Payment SDK did not load. Order saved unpaid.';return;}
   const checkout=new Razorpay({key:result.razorpay_key,amount:Math.round(result.total*100),currency:'INR',
     name:'My Restaurant',description:'Order #'+result.order_id,order_id:result.razorpay_order_id,
     handler:async function(pay){
       let v=await fetch('/api/payment/verify',{method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({order_id:result.order_id,razorpay_order_id:pay.razorpay_order_id,
        razorpay_payment_id:pay.razorpay_payment_id,razorpay_signature:pay.razorpay_signature})});
       let verified=await v.json();if(verified.ok)location.href='/orders/'+result.order_id;
       else msg.textContent=verified.error||'Payment verification failed.';
     },modal:{ondismiss:function(){msg.textContent='Order #'+result.order_id+' saved; payment remains pending.';} }});
   checkout.open();
 } else {
   msg.textContent='Order #'+result.order_id+' created. '+(method==='Cash'&&payload.cash_received?'Cash marked paid.':'Payment remains pending/manual confirmation.');
   setTimeout(()=>location.href='/orders/'+result.order_id,900);
 }
}

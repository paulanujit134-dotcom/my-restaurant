# My Restaurant — Restaurant Management / POS Web App

A runnable Flask + SQLite academic project for dine-in, takeaway and delivery operations.

## Included modules
- Staff login with hashed passwords and session-based access
- POS cart and order creation
- Menu item management (add and hide/show)
- Order register and printable receipt
- Kitchen order status board
- Sales summaries and payment-method report
- Cash payment confirmation
- Optional Razorpay Checkout for UPI/card with server-side signature verification

## Requirements
- Python 3.10+
- Internet connection only if you want to load Razorpay Checkout and accept online payments

## Run on Windows
1. Extract the ZIP and open the project folder in VS Code or Command Prompt.
2. Create a virtual environment:
   ```powershell
   py -m venv .venv
   .venv\Scripts\activate
   ```
3. Install dependencies:
   ```powershell
   pip install -r requirements.txt
   ```
4. Copy `.env.example` to `.env`. Change `SECRET_KEY` and `ADMIN_PASSWORD`.
5. Start the app:
   ```powershell
   python app.py
   ```
6. Open http://127.0.0.1:5000

Default demo login (change it in `.env` before use):
- Username: `admin`
- Password: `ChangeThisPassword123!`

## Enable real Razorpay payments
1. Create/verify a Razorpay merchant account and obtain Test Mode API Key ID and Key Secret.
2. Put them in `.env` as `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET`.
3. Restart the app. UPI and Card checkout selections will create a Razorpay order and open hosted checkout.
4. The browser sends the returned payment identifiers to `/api/payment/verify`; the server validates the HMAC signature before marking the order Paid.
5. Test with Razorpay test mode first. Never put the key secret in JavaScript or commit `.env`.

Without gateway credentials, UPI/Card orders are stored as **Pending** (manual/demo mode). The app does not pretend that a QR screenshot or user click proves payment. Confirm manual UPI/card payments against your merchant bank/UPI app before marking them paid. The included Cash checkbox records that the cashier has received cash.

## Database
SQLite database `restaurant.db` is created automatically on first run. It stores users, menu, orders and order line items. Back it up regularly. To reset demo data, stop the app and delete `restaurant.db`; it will be recreated at next startup.

## Important project notes / limitations
- GST is a clearly marked **demo 5%** calculation in `app.py` and the UI. Restaurant GST treatment/rates depend on registration, service type and current rules; ask an accountant and configure the correct tax before production.
- This is a classroom MVP, not a hardened public production deployment. Before public hosting add CSRF protection, rate limiting, HTTPS, secure cookie settings, role-based permissions, audit logs, backups, gateway webhook reconciliation, inventory purchasing/stock deduction, and tested deployment configuration.
- The Flask development server is for local development only. Do not expose it directly to the public internet.
- The app does not store raw card data. Card entry is handled by Razorpay Checkout when enabled.
